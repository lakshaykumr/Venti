#ifndef tf_constent_read
#define tf_constent_read


int turbine_constant();

#endif



