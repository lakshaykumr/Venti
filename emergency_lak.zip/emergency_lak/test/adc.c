#include <stdio.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include  <unistd.h>


void main() 
{
while(1)
{
	// Create I2C bus
	int file;
	char *bus = "/dev/i2c-2";
	if ((file = open(bus, O_RDWR)) < 0) 
	{
		printf("Failed to open the bus. \n");
		exit(1);
	}
ioctl(file, I2C_SLAVE, 0x48);
char config[3] = {0};
	config[0] = 0x01;
	config[1] = 0xBA;
	config[2] = 0x83;
	write(file, config, 3);
	sleep(1);

	// Read 2 bytes of data from register(0x00)
	// raw_adc msb, raw_adc lsb
	char reg[1] = {0x00};
	write(file, reg, 1);
	char data[2]={0};
	if(read(file, data, 2) != 2)
	{
		printf("Error : Input/Output Error \n");
	}
	else 
	{
		// Convert the data
		int adc_val = (data[0] * 256 + data[1]);
		
		/*if (raw_adc > 32767)
		{
			raw_adc -= 65535;
		}*/
		float voltage  = adc_val * 0.0078125;
		float o2 = (21/10.8) * voltage;


		// Output data to screen
		printf("ADC reading =  %d \n", adc_val);
		printf("oxygen : %f \n" , o2);
		printf("=========================================================================== \n");
	}
}
}
