#include <pthread.h>
#include "bcm2835.h"
#include <stdio.h>
#include <string.h>
#include<time.h>
#include "mine.h"
#include <unistd.h>
#include <math.h>
#include <stdint.h>
#define VREF 5.065
#define RES VREF/32767.00
//global shared variable
float calc_flow_insp = 0.0;
float calc_flow_exp = 0.0;

extern pthread_mutex_t mutex;

//float voltage_flow(float);
//void adc_start2();
//int spi_init(void);
//int ADC114S08_RegWrite(uint8_t regnum, uint8_t data , uint8_t length);
//int ADC114S08_RegRead(uint8_t regnum, uint8_t data, uint8_t length );
//void adc_start();
//void set_adc_pin(uint8_t pin_no , uint8_t gain);

int ADC114S08_RegRead(uint8_t regnum, uint8_t data, uint8_t length )
{
        char tx_buff_read[length];
        char rx_buff_read[length];
        memset(tx_buff_read, 0, length*sizeof(tx_buff_read[0]));
        memset(rx_buff_read, 0, length*sizeof(rx_buff_read[0]));
        tx_buff_read[0] = 0x20 + (regnum & 0x1f);
        tx_buff_read[1] = length -3;
        bcm2835_spi_transfernb(tx_buff_read,rx_buff_read,3);
//        printf("rxd byte = %d \n", rx_buff_read[length-1] & 0x0f);
        return rx_buff_read[length-1];
}
int ADC114S08_RegWrite(uint8_t regnum, uint8_t data , uint8_t length)
{
        char tx_buff[length];
        char rx_buff[length];
        uint8_t rxd_Data = 0;
        memset(tx_buff, 0, length*sizeof(tx_buff[0]));
        memset(rx_buff, 0, length*sizeof(rx_buff[0]));
        tx_buff[0] = 0x40 + (regnum & 0x1f);
        tx_buff[1] = 0;
        tx_buff[2] = data;
        bcm2835_spi_transfernb(tx_buff,rx_buff,3);
 rxd_Data = ADC114S08_RegRead(regnum , data , length);
        if(rxd_Data == data)
        {
                return 0;
        }
        else
                return -1;
}

float voltage_flow(float inp)
{//		printf(" Function insput voltage = %f\n" , inp);
		float input_data3;
        	float output_data3 = 0;
                input_data3 = inp;
//		printf(" Input data after divide %f \n" ,input_data3);
  //      value2 = value2/1000.00;
                if (input_data3>=0.9 && input_data3<=2.99)
                        {//      printf(" Analog output  == %f" , value);
                                output_data3 = 12.56281 * input_data3 - 12.56281;
                          //      printf(" loop 1 %f," ,output_data);
                        }
                else if (input_data3>=2.99 && input_data3<=3.82)
                        {//      printf(" Analog output  == %f " , value);
                                output_data3 = 30.12048 * input_data3 - 65.06024;
                            //    printf(" loop 2 %f," ,output_data);
                        }
                else if (input_data3>=3.82 && input_data3<=4.3)
                        {//      printf(" Analog output  == %f " , value);
                                output_data3 = 52.08333 * input_data3 - 148.9583;
                        ///	printf(" loop 3 %f," ,output_data);
                        }
                else if (input_data3>=4.3 && input_data3<=4.58)
                        {//      printf(" Analog output  == %f " , value);
                                output_data3 = 89.28571 * input_data3 - 308.9286;
                           //     printf(" loop 4 %f," ,output_data);
                        }
                else if (input_data3>=4.58 && input_data3<=4.86)
                        {//      printf(" Analog output  == %f " , value);
                                output_data3 = 178.5714 * input_data3 - 717.8571;
                             //   printf(" loop 5 %f," ,output_data);
                        }
                else if( input_data3>=4.86 )
                        {//      printf(" Analog output  == %f " , value);
                                output_data3 = 357.1429 * input_data3 - 1585.714;
                               // printf(" loop 6 %f," ,output_data);
                        }
		else if (input_data3 <= 0.5 || input_data3 >= 5.5){
			output_data3 = 0;
			}

	return output_data3;

}
float bi_directional(float input_voltage_bi)
{
	float y = 0;
	float x = input_voltage_bi;

	if(input_voltage_bi  >= 0.3 &&  input_voltage_bi  <= 0.85)
	{
			y = 285.7143*x - 442.8571;
	}
	else if(input_voltage_bi  > 0.85 &&  input_voltage_bi  <= 1.4) 
        {
                        y = 181.8182*x - 354.5455;
        }
	else if(input_voltage_bi  > 1.4 &&  input_voltage_bi  <= 2.5) 
        {
                        y = 90.90909*x - 227.2727;
        }
	else if(input_voltage_bi  > 2.5 &&  input_voltage_bi  <= 3.6) 
        {
                        y = 90.90909*x - 227.2727;
        }
	else if(input_voltage_bi  > 3.6 &&  input_voltage_bi  <= 4.15) 
        {
                        y = 181.8182*x - 554.5455;
        }
	else if(input_voltage_bi  > 4.15 &&  input_voltage_bi  <= 4.8)
        {
                        y = 285.7143*x - 985.7143;
        }

	else if ((input_voltage_bi > 4.8) || (input_voltage_bi < 0.3))
	{		y= 0 ;
		printf(" Not in range \n");
	}
	return y;
}

int spi_init(){

//  if (!bcm2835_init())return 1;

    usleep(1000);
    bcm2835_spi_begin();
    bcm2835_spi_setBitOrder(BCM2835_SPI_BIT_ORDER_MSBFIRST);
    bcm2835_spi_setDataMode(BCM2835_SPI_MODE1);
    bcm2835_spi_setClockDivider(BCM2835_SPI_CLOCK_DIVIDER_4096);
    bcm2835_spi_chipSelect(BCM2835_SPI_CS0);
    bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, LOW);
        return 1;
}
/*
void* flow_thread()
{
        uint8_t adc_ID = 0x4;//id = 100 or 0x04 first 3 bits
	int8_t analog_data2[3] = {0,0,0};
        int8_t analog_data[3] = {0,0,0};
        uint8_t read_command[3] =  {0b00010010,0,0} ;
        int output = 0;
	int output2 = 0;
        float value = -1;
	float value2 = -1;
	int msb = 0;
	int msb2 = 0;
        float input_data = 0;
        float output_data = 0;
        float input_data2 = 0;
        float output_data2 = 0;
        usleep(22000);
        spi_init();
        bcm2835_spi_transfer(RESET_OPCODE_MASK);
        if(adc_ID == ((0x4) & (ADC114S08_RegRead(ID_ADDR_MASK ,0 ,3))))
        {
                printf("Device found");
        }
       if(0 == ADC114S08_RegRead(STATUS_ADDR_MASK ,0 ,3))//0x01
        {
                printf("adc ready");
        }
        adc_start();
        while(1)
        {
	for(int i=0;i<10;i++)
	{
        bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, LOW);
	ADC114S08_RegWrite( INPMUX_ADDR_MASK, 0b10111010,3 );
        bcm2835_spi_transfernb(read_command , analog_data,3);
        msb = (int)analog_data[1] << 8 ;
        output = msb + analog_data[2];
	value = (RES) * (float)output * 1000;
      //  usleep(10);
        bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, HIGH);
	}
	input_data = value/1000.00;
//        value = value/1000.00;
	output_data=voltage_flow(input_data);
//	printf(" output_data1 = %f \n" , output_data);

/////////////////////////////////////////////////////////////////////////////////////////
	for(int i=0;i<10;i++)
	{
        bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, LOW);
        ADC114S08_RegWrite( INPMUX_ADDR_MASK, 0b10011000,3 );
        bcm2835_spi_transfernb(read_command , analog_data2,3);
        msb2 = (int)analog_data2[1] << 8 ;
        output2 = msb2 + analog_data2[2];

        value2 = (RES) * (float)output2 * 1000;
      //  usleep(10);
        bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, HIGH);
	}
	input_data2 = value2/1000.00;
  //      value2 = value2/1000.00;
	output_data2 = voltage_flow(input_data2);
//	printf(" output_data2 = %f \n" , output_data2);
	pthread_mutex_trylock(&mutex);
	calc_flow_insp = output_data - output_data2;
//	calc_flow_exp = output_data2;
	pthread_mutex_unlock(&mutex);
	}
}*/
/*
int main(){
	pthread_mutex_init(&mutex,NULL);
	pthread_t floww_thread;
	pthread_create(&floww_thread,NULL,flow_thread,NULL);
	usleep(100000);
	while(1){
			pthread_mutex_trylock(&mutex);
			printf(" inspiratory flow == %f \n " , calc_flow_insp);
		//	printf(" expiratory  flow == %f \n " , calc_flow_exp);
			pthread_mutex_unlock(&mutex);
			usleep(10000);
		}

	pthread_join(floww_thread,NULL);
	pthread_mutex_destroy(&mutex);

}
*/

void adc_start(){

ADC114S08_RegWrite( STATUS_ADDR_MASK, 0x80,3 );// flpor write 1 to clear the flag

ADC114S08_RegWrite( INPMUX_ADDR_MASK, 0b10111010,3 );// +v ain0 and -ve ain1  differential mode

ADC114S08_RegWrite( PGA_ADDR_MASK, 0xE0,3 );//14.tmod pga power down gain = 2

ADC114S08_RegWrite( DATARATE_ADDR_MASK, 0x1D,3 );// g_chp dis , internal clk=4.09Mhz , continous , l$

ADC114S08_RegWrite( REF_ADDR_MASK, 0x00,3 );// ref mon disable , +ve and -ve buffer disable,ref p0 a$

ADC114S08_RegWrite( IDACMAG_ADDR_MASK, 0x00,3 );// dasable pga , low side open write 00 , idac off

ADC114S08_RegWrite( IDACMUX_ADDR_MASK, 0xff,3 );// rdac both disconnected

ADC114S08_RegWrite( VBIAS_ADDR_MASK, 0x00,3 );// vbias off

ADC114S08_RegWrite( SYS_ADDR_MASK, 0x18,3 );//disable sys monitor 8 sampls , spi & crc& status = dis$

ADC114S08_RegWrite( OFCAL0_ADDR_MASK, 0x00,3 );

ADC114S08_RegWrite( OFCAL1_ADDR_MASK, 0x00,3 );

ADC114S08_RegWrite( OFCAL2_ADDR_MASK, 0x00,3 );

ADC114S08_RegWrite( FSCAL0_ADDR_MASK, 0x00,3 );

ADC114S08_RegWrite( FSCAL1_ADDR_MASK, 0x00,3 );

ADC114S08_RegWrite( FSCAL2_ADDR_MASK, 0x40,3 );// default

ADC114S08_RegWrite( GPIODAT_ADDR_MASK, 0x00,3 );

ADC114S08_RegWrite( GPIOCON_ADDR_MASK, 0x00,3 );

//      bcm2835_spi_transfer(0x16);//self offset command
        bcm2835_spi_transfer(0x19);//self offset command
        usleep(5000);
//        bcm2835_spi_transfer(START_OPCODE_MASK);
}




