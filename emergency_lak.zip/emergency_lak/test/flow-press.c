#include <stdio.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include<math.h>
#define I2C_IO_ERROR -100
#define IO_ERROR_AMS -998
#define FILE_OPEN_ERROR_AMS -999
float Pmax = 1.5;
float pressure_raw,pressuref,prescmh20;
float Pmin = 0;
float Digout_max = 29491.0;
float Digout_min = 3277.0;
int read_pressure(int);
int start_bus();
int file;
char *bus = "/dev/i2c-2";
int pressure_1 = 0;
float Pressure, Flow;
char data[4] = {0};
char  data2[4] = {0};
//float Sensp = (Digout_max-Digout_min )/(Pmax - Pmin);
int start_bus()
{
	if((file = open(bus, O_RDWR)) < 0)
	{
		printf("Failed to open the bus. \n");
	//	exit(1);
		return FILE_OPEN_ERROR_AMS;
	}
	return 0;
}

int pressure(int address2)
{
ioctl(file, I2C_SLAVE, address2);
	if(read(file, data2, 4) != 4)
        {
                printf("Error : Input/Output error \n");
		//syslog_function(error_PRESSURE_I2C_IO);
                return I2C_IO_ERROR;

        }
	pressure_raw = (data2[0] * 256 + data2[1]);
	pressuref = ((pressure_raw - 3277.0) / ((26214.0) / 1.5)) + 0;
	prescmh20 = pressuref * 70.307;
	return prescmh20 ;
}


float flow(int address)

{

double area_1 = 0.000950625; //in metres square
double area_2 = 0.000085785;
float rho=1.225;
double pressure_reading,c, pcmh2o, volume_divisor,massFlow,volFlow,volFlow_min,flow_lpm,pressure;
int pressure_1;
char data[4] = {0};

	ioctl(file, I2C_SLAVE, address);
	if(read(file, data, 4) != 4)
	{
		printf("Error : Input/Output error \n");
	//	syslog_function(error_FLOW_I2C_IO);
	//	return I2C_IO_ERROR;
	}
	pressure_1 = (0x3f & data[0]) << 8;
	pressure = pressure_1 | data[1];
	//pressure = 0x3fff & ((data[0] * 256) + data[1]);
	pressure_reading=(((500.0-(-500.0))/(14765.0-1638.0))*(pressure-1638.0)+(-500.0));
	pcmh2o= pressure_reading*0.010197162129779282;
	volume_divisor=( ( 1.0 / ((area_2*area_2) )-(1.0/ (area_1*area_1)) ));
	massFlow=1000*(sqrt( (abs(pressure_reading)*2.0*rho)/volume_divisor));
	volFlow =( massFlow/rho)*1000.0 * 0.72; //ml/sec
	volFlow_min=(volFlow*60); //ml/min
	flow_lpm=volFlow_min*0.001 ; //lpm
	return (float)flow_lpm;
}


int main()
{
	start_bus();

   	 while(1)
	{
	Flow =flow(0x28);
	Pressure = pressure(0x78);
	printf("Pressure =%f\n", Pressure);
	printf("flow =%f\n", Flow);
	sleep(1);

	}
	return 0;
}


