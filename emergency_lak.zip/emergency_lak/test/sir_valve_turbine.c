#include "bcm2835.h"
#include <stdio.h>

#define PIN12 12
#define PIN13 13
#define PIN18 18
#define PIN19 19

#define PWM_CHANNEL0 0
#define PWM_CHANNEL1 1

#define RANGE 274//35khz    FOr turbine 
#define RANGE1 19200 //1428//384//25	    for valve 
#define turbine_factor  .274
#define valve_factor 192.00//14.28//3.84


int pwm_init(void)
{
    if (!bcm2835_init())
        return 1;

    bcm2835_gpio_fsel(PIN13, BCM2835_GPIO_FSEL_ALT0);// channel 1
    bcm2835_gpio_fsel(PIN18, BCM2835_GPIO_FSEL_ALT5);// channel 0

    bcm2835_pwm_set_clock(BCM2835_PWM_CLOCK_DIVIDER_2);
    bcm2835_pwm_set_mode(PWM_CHANNEL0, 1, 1);
    bcm2835_pwm_set_range(PWM_CHANNEL0, RANGE);
    bcm2835_pwm_set_mode(PWM_CHANNEL1, 1, 1);
    bcm2835_pwm_set_range(PWM_CHANNEL1, RANGE1);

   // bcm2835_close();
    return 0;
}
int turbine_duty_cycle(float tdc)
{
	//tdc = tdc/10;
	bcm2835_pwm_set_data(PWM_CHANNEL0,(int)tdc*turbine_factor);//turbine
	return 0;
}

int valve_duty_cycle(float vdc)
{

	bcm2835_pwm_set_data(PWM_CHANNEL1,(int)vdc*valve_factor );//valve
	return 0;
}
/*
int main()
{
	pwm_init();
	turbine_duty_cycle(396);

}
*/
