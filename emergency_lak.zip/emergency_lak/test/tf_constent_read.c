#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Return 1 if file is not present
int order_count = 10, const_count = 0;//y=10;
char* value ;
char *stopstring;
extern float order_10;//=    constant[10];// (-1.35380345)*0.00000000$
extern float order_9;// =    constant[9];//( 5.64933421)*0.0000000000$
extern float order_8;// =    constant[8];//( -1.00993791)*0.00000001;$
extern float order_7;// =    constant[7];//(1.01042270 )*0.000001;//p$
extern float order_6;// =    constant[6];//(-6.20248001)*0.00001;//po$
extern float order_5;// =    constant[5];//( 2.41040457)*0.001;//pow($
extern float order_4;// =    constant[4];//(-5.91526874)*0.01;//pow( $
extern float order_3;// =    constant[3];//(8.91528337)*0.1 ;//pow( 1$
extern float order_2;// =    constant[2];//(-7.94133717)*1 ;//pow( 10$
extern float order_1;// =    constant[1];//( 5.05125439)*10 ;//pow( 1$
extern float order_0;// =    constant[0];//(5.32425150)*10; //pow( 10$


long double  constant [11];

int  turbine_constant()
{
    FILE  *fr;

	fr = fopen("/home/pi/pro_venti/tf_constant_write.csv", "r");

    if (!fr){
        printf("Can't open file\n");
	return (1);
	}
    else {

	char buffer[1024];


        	while (fgets(buffer,1024, fr))
		 {
            		char* value = strtok(buffer, "e");

            		printf("long double order%d  ",order_count);

			long double data = strtold(value,&stopstring);// 'data' stores before 'e' values
               		value = strtok(NULL, "e");

			int pow_data = atoi(value); // 'pow_data' stores  power of 'e' data
			constant[const_count] = data * pow(10,pow_data);

			printf("  %.30lf", constant[const_count]); // constant[] store all constants
           		printf("\n");
			const_count++; order_count--;
	        }
	fclose(fr);

	const_count = 0;
	order_10=    constant[10];// (-1.35380345)*0.00000000$
	order_9 =    constant[9];//( 5.64933421)*0.0000000000$
	order_8 =    constant[8];//( -1.00993791)*0.00000001;$
	order_7 =    constant[7];//(1.01042270 )*0.000001;//p$
	order_6 =    constant[6];//(-6.20248001)*0.00001;//po$
	order_5 =    constant[5];//( 2.41040457)*0.001;//pow($
	order_4 =    constant[4];//(-5.91526874)*0.01;//pow( $
	order_3 =    constant[3];//(8.91528337)*0.1 ;//pow( 1$
	order_2 =    constant[2];//(-7.94133717)*1 ;//pow( 10$
	order_1 =    constant[1];//( 5.05125439)*10 ;//pow( 1$
	order_0 =    constant[0];//(5.32425150)*10; //pow( 10$
    }

    return 0;
}
