#ifndef sir_valve_turbine
#define sir_valve_turbine

int pwm_init(void);
int turbine_duty_cycle(float);
int valve_duty_cycle(float);

#endif
