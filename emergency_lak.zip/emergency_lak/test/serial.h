#ifndef serial
#define serial

int serial_data_write(char *);
int serial_data_read();


#endif
