void pwm_init(void);
//int pwm_write_duty(int duty);
int turbine_duty_cycle(float duty);
//int valve_duty_cycle(float vdc);
int valve_duty_cycle(int vdc);
