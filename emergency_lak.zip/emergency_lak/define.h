#ifndef define
#define define

#include <stdio.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include <syslog.h>
#include <signal.h>
#endif
