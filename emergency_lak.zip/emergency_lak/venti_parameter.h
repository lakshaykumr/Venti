#ifndef venti_parameter
#define venti_parameter

float LEAK_FLow(float,float );
float compliance_function(float ,float,float );

#endif
