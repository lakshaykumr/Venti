#ifndef breaking
#define breaking
extern int break_init(void);
extern int break_on(void);
extern int break_off(void);
extern float break_time(float peep,float Pinsp);
#endif

