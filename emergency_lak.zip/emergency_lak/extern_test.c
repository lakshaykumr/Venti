#include<stdio.h>
void main()
{
extern float lax;

printf("%lf",lax);

}
