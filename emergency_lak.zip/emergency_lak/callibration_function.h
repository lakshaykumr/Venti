//#ifndef callibration_function
//#define callibration_function

//float insp_calib();
//float exp_calib();
int both_calib(float * , float *);
//#endif
