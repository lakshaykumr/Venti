#ifndef extra
#define extra


float min(float num1, float num2);
float max(float num1, float num2);

#endif

