#ifndef exhale_valve
#define exhale_valve
void pin_export(void);
void valve_direction(void);
void valve_close(void);
void valve_open(void);
void pin_unexport(void);
#endif
