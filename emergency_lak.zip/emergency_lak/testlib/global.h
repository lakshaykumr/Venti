#ifndef global
#define global
#define I2C_IO_ERROR 404

int dt,duty,duty_in,duty_ex;
float dtcos;
char string[10];
double pressure, Flow_lpm,var,volume,flow_lpm,prescmh20;
long  timer2;
int file;
int x,y,i;
float in_time;//seconds
float ex_time;//seconds
double offset_press, offset_flow;

#endif
