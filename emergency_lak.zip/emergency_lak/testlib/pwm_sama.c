#include"header.h"
#include"global.h"
//#include"pwm.h"
//#include"error.h"


char error_open_period[] = "Unable to open /sys/class/pwm/pwmchip0/pwm1/period\n";
char error_write_period[] = "Error writing to /sys/class/pwm/pwmchip0/pwm1/period\n";
char error_open_duty_cycle[] = "Unable to open /sys/class/pwm/pwmchip0/pwm1/duty_cycle\n";
char error_write_duty_cycle[] = "Error writing to /sys/class/pwm/pwmchip0/pwm1/duty_cycle\n";
char error_open_enable[] = "Unable to open /sys/class/pwm/pwmchip0/pwm1/enable\n";
char error_write_enable[] = "Error writing to /sys/class/pwm/pwmchip0/pwm1/enable\n";
char error_open_export[] = "Unable to open /sys/class/pwm/pwmchip0/export\n";
char error_write_export[] = "Error writing to /sys/class/pwm/pwmchip0/export\n";
char error_open_polarity[] = "Unable to open /sys/class/pwm/pwmchip0/pwm1/polarity\n";
char error_write_polrity[] = "Error writing to /sys/class/pwm/pwmchip0/pwm1/polarity\n";




//PWM_FUNCTION(START)

void pwm_setting(void)

{

if((access("/sys/class/pwm/pwmchip0/pwm1/period" , F_OK ) == 0))
    			{				// location check for pwm0. if pwm0 is avialable then they skip export part 
			printf( " gpio pin is already populated dont need to export \n");
    			}

else
{
int fd6 = open("/sys/class/pwm/pwmchip0/export", O_WRONLY);
    if (fd6 == -1)
    {
        perror("Unable to open /sys/class/pwm/pwmchip0/export");
        //syslog_function(error_open_export);
        exit(1);
    }

    if (write(fd6, "1", 1) != 1)
    {
        perror("Error writing to /sys/class/pwm/pwmchip0/export");
        //syslog_function(error_write_export);
        exit(1);
    }

    close(fd6);
}
}

int pwm_start(int duty)
{

dtcos = (duty/100.0) * (20000000);
dt = (int)(dtcos);
sprintf(string, "%d", dt);

int fd1 = open("/sys/class/pwm/pwmchip0/pwm1/period", O_WRONLY);
    if (fd1 == -1)
    {
        perror("Unable to open /sys/class/pwm/pwmchip0/pwm1/period");
        //syslog_function(error_open_period);
	exit(1);
    }

    if (write(fd1, "20000000", 8) != 8)
    {
        perror("Error writing to /sys/class/pwm/pwmchip0/pwm1/period");
        //syslog_function(error_write_period);
	exit(1);
    }

    close(fd1);


int fd2 = open("/sys/class/pwm/pwmchip0/pwm1/duty_cycle", O_WRONLY);
    if (fd2 == -1)
    {
        perror("Unable to open /sys/class/pwm/pwmchip0/pwm1/duty_cycle");
        //syslog_function(error_open_duty_cycle);
	exit(1);
    }

    if (write(fd2, string, 8) != 8)
    {
        perror("Error writing to /sys/class/pwm/pwmchip0/pwm1/duty_cycle");
	//syslog_function(error_write_duty_cycle);
        exit(1);
    }

    close(fd2);

int fd3 = open("/sys/class/pwm/pwmchip0/pwm1/enable", O_WRONLY);
    if (fd3 == -1)
    {
        perror("Unable to open /sys/class/pwm/pwmchip0/pwm1/enable");
        //syslog_function(error_open_enable);
	exit(1);
    }

    if (write(fd3, "1", 1) != 1)
    {
        perror("Error writing to /sys/class/pwm/pwmchip0/pwm1/enable");
	//syslog_function(error_write_enable);
        exit(1);
    }
    close(fd3);

int fd7 = open("/sys/class/pwm/pwmchip0/pwm1/polarity", O_WRONLY);
    if (fd7 == -1)
    {
        perror("Unable to open /sys/class/pwm/pwmchip0/pwm1/polarity");
	//syslog_function(error_open_polarity);
        exit(1);
    }

    if (write(fd7, "inversed", 8) != 8)
    {
        perror("Error writing to /sys/class/pwm/pwmchip0/pwm1/polarity");
	//syslog_function(error_write_polarity);
        exit(1);
    }

    close(fd7);


}

//PWM_FUNCTION(STOP)
int pwm_stop()
{

int fd5 = open("/sys/class/pwm/pwmchip0/pwm1/enable", O_WRONLY);
    if (fd5 == -1)
    {
        perror("Unable to open /sys/class/pwm/pwmchip0/pwm1/enable");
        //syslog_function(error_open_disable);
	exit(1);
    }

    if (write(fd5, "0", 1) != 1)
    {
        perror("Error writing to /sys/class/pwm/pwmchip0/pwm1/enable");
        //syslog_function(error_write_disable);
	exit(1);
    }
    close(fd5);

int fd7 = open("/sys/class/pwm/pwmchip0/unexport", O_WRONLY);
    if (fd7 == -1)
    {
        perror("Unable to open /sys/class/pwm/pwmchip0/unexport");
        //syslog_function(error_open_export);
        exit(1);
    }

    if (write(fd7, "1", 1) != 1)
    {
        perror("Error writing to /sys/class/pwm/pwmchip0/unexport");
        //syslog_function(error_write_export);
        exit(1);
    }

    close(fd7);


printf("=====Turbine Stoped===== \n");
}


int main()
{
int count = 0;
pwm_setting();

while (count <= 5)
{
pwm_start(60);
sleep(1);
pwm_start(20);
sleep(1);
count ++;
}

pwm_stop();
}
