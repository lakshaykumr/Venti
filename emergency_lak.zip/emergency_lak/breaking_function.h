#ifndef __BREAKING_FUNCTION__
#define __BREAKING_FUNCTION__
//#include "stdio.h" 
int break_init(void);
int breaking ( float pplat , float peep , int time);
int breaking_enable ( float pplat , float peep , int time);

#endif /* EOD */
