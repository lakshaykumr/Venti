int syslog_function(char *error_no) ;   





