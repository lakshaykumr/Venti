#ifndef serial
#define serial

int serial_data_write(char* data);
int serial_data_read();


#endif
